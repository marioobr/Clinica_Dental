﻿using System;
using System.Data;
using MySql.Data;
using System.Text;
using seguridad.entidades;
using Gtk;

namespace seguridad.datos
{
    public class dtUsuarios
    {
        Conexion con = new Conexion();

        #region metodos
        public bool GuardarUsuarios(Tbl_user tus)
        {
            bool guardado = false; // esto es una bandera
            int x = 0; //variable de control

            MessageDialog ms = null;
            StringBuilder sb = new StringBuilder();
            sb.Append("INSERT INTO User");
            sb.Append("(User.User, User.Pws, User.Nombres, User.Apellidos, User.Email, User.Estado)");
            sb.Append("VALUES ('" + tus.User + "','" + tus.Pwd +"','"+tus.Nombres+"','"+tus.Apellidos1+"','"+tus.Email+ "','" +1+ "')");

            try
            {
                con.abrirConexion();
                x = con.Ejecutar(CommandType.Text, sb.ToString());

                if(x>0)
                {
                    guardado = true;
                    ms = new MessageDialog(null, DialogFlags.Modal,
                    MessageType.Info, ButtonsType.Ok, "se guardo el usuario con exito!!!");
                    ms.Run();
                    ms.Destroy();
                }
                return guardado;
            }
            catch(Exception e)
            {
                ms = new MessageDialog(null, DialogFlags.Modal,
                     MessageType.Error, ButtonsType.Ok,e.Message);
                ms.Run();
                ms.Destroy();
                throw;
            }
        }//fin del metodo

        public ListStore ListarUsuarios()
        {
            ListStore datos = new ListStore(typeof(string), typeof(string),
            typeof(string), typeof(string), typeof(string));
            StringBuilder sb = new StringBuilder();
            MessageDialog ms = null;
            IDataReader dr = null;
            sb.Append("SELECT User.idUser, User.User, User.Nombres, User.Apellidos, User.Email FROM seguridad.User");

            try
            {
                con.abrirConexion();
                dr = con.Leer(CommandType.Text, sb.ToString());
                while(dr.Read())
                {
                    datos.AppendValues(dr[0].ToString(), dr[1].ToString(),
                    dr[2].ToString(), dr[3].ToString(), dr[4].ToString());
                    //dr.close();
                }
                return datos;
            }catch(Exception e)
            {
                ms = new MessageDialog(null, DialogFlags.Modal, MessageType.Error, ButtonsType.Ok, e.Message);
                ms.Run();
                ms.Destroy();
                throw;
            }
            finally
            {
                dr.Close();
                con.CerrarConexion();
            }
        }//fin de metodo

        //Metodo para validar si el usuario existe
        public bool ExisteUser(Tbl_user tus)
        {
            bool existe = false;
            IDataReader idr = null;
            StringBuilder sb = new StringBuilder();
            sb.Append("USE seguridad;");
            sb.Append("SELECT * FROM `seguridad`.`User` WHERE `User`.`User` = "+"'" + tus.User + "';");

            try
            {
                con.abrirConexion();
                idr = con.Leer(CommandType.Text, sb.ToString());
                if(idr.Read())
                {
                    existe = true;
                }
                return existe;
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
                Console.WriteLine(e.StackTrace);
                throw;
            }
            finally
            {
                idr.Close();
                con.CerrarConexion();
            }
        }//fin del metodo

        #endregion
        public dtUsuarios()
        {
        }
    }
}
