﻿using System;
using Gtk;
using seguridad.datos;
using seguridad.entidades;
using seguridad.Negocio;


namespace seguridad
{
    public partial class Frm_Usuarios : Gtk.Window
    {

        dtUsuarios dtus = new dtUsuarios();
        Negocio.NgUsuario ntus = new Negocio.NgUsuario();

        public Frm_Usuarios() :
                base(Gtk.WindowType.Toplevel)
        {
            this.Build();
            tvwUsuarios.Model = dtus.ListarUsuarios();
            string[] titulos = { "id Usuario", "Usuario", "Nombres", "Apellidos", "Email"};

            for (int i = 0; i < titulos.Length; i++)
            {
                tvwUsuarios.AppendColumn(titulos[i], new CellRendererText(), "text", i);
            }
        }

        public void LimpiarCuadrosdeTexto()
        {
            txtNombres.Text = "";
            txtApellidos.Text = "";
            txtCorreo.Text = "";
            txtClave1.Text = "";
            txtClave2.Text = "";
            txtUsuarios.Text = "";
        }

        protected void OnSalirActionActivated(object sender, EventArgs e)
        {
            Application.Quit();
        }

        protected void OnBtnGuardarClicked(object sender, EventArgs e)
        {
            Tbl_user tus = new Tbl_user();
            tus.User = this.txtUsuarios.Text;
            tus.Nombres = this.txtNombres.Text;
            tus.Apellidos1 = this.txtApellidos.Text;
            tus.Email = this.txtCorreo.Text;
            /*tus.Pwd = this.txtClave1.Text;
            tus.Pwd_temp = this.txtClave2.Text;*/

            if(this.txtClave1.Text.Trim().Equals(this.txtClave2.Text.Trim()))
            {
                tus.Pwd = this.txtClave1.Text;
                //dtUsuarios dtus = new dtUsuarios();

                if(ntus.NgGuardarUser(tus))
                {
                    MessageDialog ms = null;
                    ms = new MessageDialog(null, DialogFlags.Modal, MessageType.Info, ButtonsType.Ok, "El usuario se guardo correctamente");
                    ms.Run();
                    ms.Destroy();
                    LimpiarCuadrosdeTexto();
                    tvwUsuarios.Model = dtus.ListarUsuarios();
                }

                /*if (dtus.GuardarUsuarios(tus))
                {
                    MessageDialog ms = null;
                    ms = new MessageDialog(null, DialogFlags.Modal, MessageType.Info, ButtonsType.Ok, "El usuario se guardo correctamente");
                    ms.Run();
                    ms.Destroy();
                    LimpiarCuadrosdeTexto();
                    tvwUsuarios.Model = dtus.ListarUsuarios();
                }*/
                else
                {
                    MessageDialog ms = null;
                    ms = new MessageDialog(null, DialogFlags.Modal, MessageType.Warning, ButtonsType.Ok, "Revise los datos e intente nuevamente");
                    ms.Run();
                    ms.Destroy();
                    this.txtUsuarios.GrabFocus();
                }
            }
            else
            {
                MessageDialog ms = null;
                ms = new MessageDialog(null, DialogFlags.Modal, MessageType.Warning, ButtonsType.Ok, "las contrasenias no coinciden");
                ms.Run();
                ms.Destroy();
            }


        }

        protected void OnBtnEliminarClicked(object sender, EventArgs e)
        {
        }

        protected void OnBtnCancelarClicked(object sender, EventArgs e)
        {
            LimpiarCuadrosdeTexto();
        }
    }
}
