﻿using System;
namespace seguridad.datos
{
    public class dtUserRol
    {
        public dtUserRol()
        {
        }
    }
}
